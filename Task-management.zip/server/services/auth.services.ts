import bcrypt from "bcrypt";
import { User } from "../models/index.ts";
import generateToken from "../utils/generateToken.ts";
import { email } from "zod";

export const signUpService = async (data: {
  name: string;
  email: string;
  password: string;
}) => {
  if (!data.email) throw new Error("Email not provided");
  if (!data.password) throw new Error("Password not provided");
  const userExist = await User.findOne({ email: data.email });
  if (userExist) throw new Error("Email already exist.");

  const hashedPassword = await bcrypt.hash(data.password, 10);
  await User.create({
    name: data.name,
    email: data.email,
    password: hashedPassword,
  });
};

export const loginService = async (data: {
  email: string;
  password: string;
}) => {
  if (!data.email) throw new Error("Email not provided");
  if (!data.password) throw new Error("Password not provided");

  const user = await User.findOne({ email: data.email });
  if (!user) throw new Error("Email not found");
  const result = await bcrypt.compare(data.password, user.password);
  if (!result) throw new Error("Password is incorrect");
  const payload = {email : data.email};
  const token = generateToken(payload);
  return token;
};
